                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2243854
Material Test Card for Laser Cutting (SVG) by erpel09 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

**This is a remix of Noloxs's Laser Cutting Material Template.**
http://www.thingiverse.com/thing:728579

I've converted it to SVG format using Inkscape and changed some text fields.

**To use this in LaserWeb, I do this:**
- Open mtc-engrave.svg in Inkscape and enter the details of your test print (material, speed...)
- Export mtc-engrave to PNG format (File / Export as PNG). 
 Make sure to select *page* as export area and use the same DPI as in LaserWeb!
- Open LaserWeb
- Import **mtc-cut.svg** for the cutting lines
- Import **mtc-engrave.png** for the raster engraving
- Change the settings in LaserWeb according to your test
- Fire! :-)

For new materials, I use engrave-small.png first to quickly try different settings.

**The size of this test card is 140mm x 190mmm.**
I'm using 200mm x 300mm sheets in my K40 cutter, i.e. I can put two cards on each sheet.